---
name: java-rules
description: Use for Java 8 / Spring Boot 2.7 backend rules when working in the active agent-java project.
---

# Java 8 backend rules (Pi)

- Confirm the target is the active Java 8 / Spring Boot 2.7 backend project before editing.
- Keep API, domain, application, and infrastructure responsibilities separated according to the existing project structure.
- Do not change a public JSON contract, migration, or dependency direction without a spec or explicit acceptance criterion.
- Never commit credentials; use environment variables or the project's existing secret mechanism.
- Match the child project's build and test command; report the exact command or IDE verification actually run.
