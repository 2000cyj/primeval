---
name: typescript
description: TypeScript conventions for the Vue frontend — strict mode, type-only imports, generic component patterns, and how to type Vue refs/props/emits.
---

# TypeScript conventions (frontend)

## Pin this

- `tsconfig.json` runs in **strict mode** (`strict: true`,
  `noUncheckedIndexedAccess: true`).
- Type-only imports use `import type { Foo } from '...'`. Do not mix
  value and type imports unless the symbol is both.
- Use `satisfies` over `as` when narrowing a literal to a known shape
  but keeping the literal's narrower type.

## Vue-specific typing

- `ref<T>()` — explicit generic only when the initial value is null or
  you need a wider type than inferred.
- `defineProps<{ foo: string; bar?: number }>()` — props are typed at
  the call site, no runtime declaration needed.
- `defineEmits<{ change: [value: string]; submit: [] }>()` — tuple-style
  payload typing.
- `withDefaults(defineProps<...>(), { ... })` — apply defaults.

## Forbidden

- `any` — use `unknown` and narrow, or define a proper type.
- `// @ts-ignore` — use `// @ts-expect-error` with a reason string,
  and only when the underlying lib has a known bug.
- Non-null assertions (`!`) — use a runtime check or proper narrowing.
