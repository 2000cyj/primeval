---
name: vue
description: Vue 3 framework conventions — Composition API, reactivity gotchas, lifecycle hooks, slot patterns, and the common differences from Vue 2.
---

# Vue 3 conventions

When answering anything about Vue 3 (the framework, not this codebase),
call `mcp__context7__query-docs` with `libraryId=/vuejs/core` and a
single-concept query.

## Pin this

- Composition API + `<script setup lang="ts">` is the default.
- Reactivity primitives: `ref` for primitives, `reactive` for objects,
  `computed` for derived values, `watch` / `watchEffect` for side effects.
- Lifecycle hooks are `onMounted`, `onUnmounted`, `onUpdated`, etc. —
  they must be called synchronously inside `setup`.
- Props are typed with `defineProps<{...}>()`, emits with
  `defineEmits<{...}>()`.
- Slots: `<slot />` and named slots `<slot name="header" />`.

## Watch out for

- **Ref unwrapping in templates**: refs are auto-unwrapped in templates
  but **not** in script. `count.value++` in script, `count++` in
  template.
- **`watch` default is shallow**: pass `{ deep: true }` if watching a
  nested object.
- **`v-for` + `:key`**: always provide a stable `:key`, never the array
  index.
- **Reactive destructure loses reactivity**: use `toRefs` /
  `storeToRefs` (Pinia).

## Forbidden in this repo

- Vue 2 patterns: Options API as default, `new Vue()`, `Vue.extend`,
  `vue-cli`.
- Vuex (deprecated). Use Pinia.
- `axios` (unless the project already pins it). Use `fetch`.
