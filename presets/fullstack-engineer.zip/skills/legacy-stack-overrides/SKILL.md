---
name: legacy-stack-overrides
description: Override rules for working on Spring Boot 2.7 / Java 8 legacy services. Pins context7 library versions, restricts idea-mcp tool surface (no xdebug_*), and lists mem0 entries that should already exist for any legacy project.
---

# Legacy stack overrides — Spring Boot 2.7 / Java 8

These overrides apply to all agents in `apps/agent-java8/`. They
provide the legacy-specific Context7 version pinning, IDEA MCP tool
restrictions, and mem0 guidance for this active Java 8 project.

## context7 — legacy library version pins

Use `mcp__context7__resolve-library-id` and pick the legacy version when
querying Spring, Spring Boot, Hibernate, etc. Examples of correct IDs:

- Spring Boot 2.7.x: `/spring-projects/spring-boot/v2.7.18`
- Spring Framework 5.3.x: `/spring-projects/spring-framework/v5.3.31`
- Hibernate 5.6 (the default on Boot 2.7): `/hibernate/orm/5.6`
- Lombok (pin to 1.18.30 on Java 8): `/projectlombok/lombok/1.18.30`
- springdoc-openapi 1.x (Boot 2 line): `/springdoc/springdoc-openapi/1.7.0`

**Hard rule:** if `context7` returns only the Boot 3+ doc, **switch the
version suffix explicitly** before answering. Never answer from a Boot 3+
doc when the project is on Boot 2.

## IDEA MCP 编译与构建强制规则

- Java8 子项目的代码编译、模块构建、测试运行前的编译验证，必须使用 IDEA MCP 的 `mcp__idea__build_project` 或对应的 IDEA MCP 运行/测试工具；不得以 shell 中直接执行 `mvn`、`mvnw`、`gradle` 等命令替代 IDEA MCP 编译验证。
- 任何 IDEA MCP 操作（读取、搜索、修改、构建、运行、调试、问题检查、VCS 或数据源访问）都必须先加载并严格遵守 `remote-idea-mcp-usage`，尤其是代理范围确认、最小操作范围、已有改动保护和数据库连接权限规则。
- 调用 IDEA MCP 前，必须确认当前代理实例及项目根目录覆盖目标；无法确认目标在代理范围内时停止操作，不得通过 IDEA 终端或脚本绕过范围限制。
- 编译验证至少记录项目路径、实际重建模块/文件、构建结果和未验证范围。构建成功只代表 IDEA MCP 实际执行的范围通过。
- `mvn clean verify` 仅可作为用户明确要求且 IDEA MCP 无法完成等价验证时的例外候选；不得作为 Java8 子项目的默认编译路径，也不得以其替代 `remote-idea-mcp-usage` 规定的 IDEA MCP 流程。

Legacy services (e.g. `bi-FOB`) often have older IntelliJ project layouts
(`.idea/` + `.iml` files, no `pom.xml`-only opening). When passing
`projectPath`, pass the legacy root directly:

```
build_project(projectPath="D:/OB/bi-FOB/bi-cashier")
```

The `xdebug_*` tools are **not** in `apps/agent-java8/.pi/settings.json`'s
IDEA MCP config (replaces the historical `opencode.json`'s
`mcp.idea-mcp.tools` list for `agent-java8/`) — they are unavailable
on legacy IDE integrations. Do not try to call them.

Database connections on legacy projects are usually **read-only**. The
"connection name stripped of whitespace equals `dev`" write-allowance rule
applies; in practice most legacy DBs are named after environments (e.g.
`bi_test`, `bi_pre`, `bi_prod`) — none of these are writable.

## mem0 — legacy decisions worth pinning

Common Java 8 / Boot 2 decisions worth a memory entry:

- Pinned Lombok version (often 1.18.30, never above)
- Whether the project uses `javax.*` or has been partially migrated to
  `jakarta.*`
- Whether the build runs on JDK 1.8 or JDK 11/17 but emits 1.8 bytecode
- Internal "do not upgrade" notes (e.g. "this service stays on Boot 2.7
  because X dependency has no Boot 3 release")

Before recommending any upgrade, search these memories first. Do not
re-litigate a settled "stay on 2.7" decision.
