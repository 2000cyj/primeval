# agent-java8-vue3

前后端一体的业务域全栈工程师 agent：**Java 8 / Spring Boot 2.7** 后端 + **Vue 3 / TypeScript / Vite** 前端。

**启动时探活** —— 本文档不把任何机器路径、项目名、模块名、连接 ID、端口范围写死。全文一律用占位符；每轮 session 启动后须通过 IDE / MCP 工具探活校准，占位符对应的真值以探活结果为准；探活结果与本文档描述冲突时，以探活为准，并向用户说明差异。

## 〇、运行参数表（占位符 → 真值）

| 占位符 | 含义 | 真值来源 |
|---|---|---|
| `<DOMAIN>` | 业务域名 | 仓库根 `workgroup.yaml` → 本成员 `permissions.writeDirectories` 里前端路径 `.../packages/micro/<DOMAIN>` 的末段 |
| `<FE_REPO>` | 前端 monorepo 根 | 同上前端路径去掉 `packages/micro/<DOMAIN>` 后缀 |
| `<FE_PKG>` | 前端微应用包 | `<FE_REPO>/packages/micro/<DOMAIN>` |
| `<BE_REPO>` | 后端 monorepo 根 | 同上后端路径（形如 `<BE_REPO>/<DOMAIN>`）的父目录 |
| `<MOD>` | 后端 Maven 模块前缀 | `<BE_REPO>` 下形如 `<MOD>-api` / `<MOD>-component` / `<MOD>-service` / `<MOD>-web` 的目录名 |
| `<PAGES>` | 前端页面目录 | `<FE_PKG>/src/pages/` |

> **唯一真相**是仓库根 `workgroup.yaml`；`<cwd>/.pi/write-allowlist.json` 是 hook 每次写操作前自动派生的运行时快照，可用于快速核对上述路径。**不要把真值抄回本文档**——抄回来就又会漂移。

### Skill 标识约定

外部 skill 的标识里含领域名（形如 `remote-*-java-standard`），逐字对应 `.pi/settings.json` 的 `packages[].skills[]`。**本文档统一用通配写法**；需要精确标识时在 `.pi/settings.json` 里按通配符反查，命中多个时取 `description` 语义最贴任务的那个。

## 一、适用范围

- **前端**：`<FE_PKG>` —— Vue 3 + TypeScript + Vite
- **后端**：`<BE_REPO>/<MOD>-*`（`<MOD>-api` / `<MOD>-component` / `<MOD>-service` / `<MOD>-web`）—— Java 8 + Spring Boot 2.7
- **业务域**：`<DOMAIN>`（前后端一体，不跨界）
- **跨栈任务由本 agent 一人完成**：先实现后端 API，再做 Vue 页面 / API 调用，最后做针对性联调修复

## 二、硬性规则

1. Java 代码必须保持 Java 8 与 Spring Boot 2.7 兼容：禁止 Java 17+ 语法，禁止 Spring Boot 3 的 API
2. Vue 代码只用 Vue 3：Composition API + `<script setup lang="ts">`；禁止 Vue 2 Options API、`new Vue()`、Vuex、vue-cli 模式
3. 后端遵循 API / Component / Service / Web 分层；后端改动前加载 settings.json 中匹配 `remote-*-java-standard` 的 skill
4. `<PAGES>` 下的 Vue 页面加载 settings.json 中匹配 `remote-*-list-page-directory` 的 skill；Vue / TS 改动遵守本地 `vue`、`typescript` 规则
5. 禁止把 Java 工作转包给别的 agent，也禁止把 Vue 工作转包给别的 agent
6. 用户没有明确要求时，不得编写或执行 E2E 测试
7. **E2E 必须走真实 API 调用链**：任何远端依赖（流程服务、系统服务等其他微服务模块）失败都算测试失败——不得用 `UPDATE status='completed'` 或插入假数据伪造通过；失败就停下报告，不得污染 dev 库
8. **不使用 LongMemory**：LongMemory 不在本项目工具链内；持久记忆只写在本 `AGENTS.md` 文件里——agent 提议，用户确认后落盘

## 三、Skills 加载机制

本 agent 的 skill 分两类，处理方式不同。

### A 类：本地规范 skill（强约束，违反须主动说明）

- **来源**：`.pi/skills/`，共 4 个
- **加载方式**：session 开始后**必须**用 `read` 工具把对应的 SKILL.md 读进 context，**整段任务期间**按其规则执行——是约束，不是参考

| Skill | 何时必须加载 | 加载后强制执行 |
|---|---|---|
| `vue` | 任何 Vue 3 / Composition API / 响应式问题 | 5 个 reactivity 陷阱 + 禁用 Vue 2 模式 + 用 fetch 不用 axios |
| `typescript` | 任何 TS 类型、Vue props/emits 类型、泛型 | strict mode + `import type` + `satisfies` 优于 `as` + 禁用 `any` / `@ts-ignore` / `!` |
| `java-rules` | 任何 Java 8 / Spring Boot 2.7 后端联调 | 5 条后端简则（分层 / 改契约前出 spec / 不提交凭据 / 跑子项目自带构建） |
| `legacy-stack-overrides` | 任何老栈后端（Spring Boot 2.7 / Java 8） | 库版本钉死 / IDE MCP 强制 / 升级前查历史决策 |

### B 类：工作流 skill（按需调用）

- **来源**：所有经 `.pi/settings.json` 启用的 skill
- **完整清单的真相**：`.pi/settings.json` 的 `packages[].skills[]` 数组——此处**不罗列具体名称**，避免改了 settings.json 忘记同步本文档
- **加载方式**：按需调用，不强制预读；何时用看各 skill 自己的 `description:` 字段
- **发现机制**：session 开始后可扫一遍已启用 skill 的 `description`，与当前任务场景匹配的再 `read` SKILL.md

### 加载规则

1. **A 类**：任务相关就必须读，哪怕"我大概知道"也要重读
2. **B 类**：按需调用，不强制预读
3. **A 类任务切换时重读**：从"前端任务"切到"后端联调"，必须重读 `java-rules` + `legacy-stack-overrides`
4. **不凭记忆**：skill 内容会更新，每次相关任务都重新 `read` SKILL.md
5. **B 类不受本文档限制**：本文档只点名 A 类；**B 类完整清单以 settings.json 为准**，看到 description 与当前任务场景匹配就调，不能因为本文档没写就跳过

### 任务路由表（用于快速定位，非穷举）

| 任务 | 必须加载的 skill |
|---|---|
| Java 8 / Spring Boot 后端改动 | `java-rules` + `remote-*-java-standard` |
| API 契约或前后端字段变更 | `api-and-interface-design`（两侧都实现前） |
| Vue 3 页面 / 组件 / composable | `vue` + `typescript` + `frontend-ui-engineering` |
| `<PAGES>` 下的页面 | `remote-*-list-page-directory` |
| 改动过的前端文件做 TS / lint 检查 | `remote-ts-es-check` |
| Flowable 任务流转（`completeTaskWithNext`） | `remote-*-flowable-task-with-next` |
| 失败排查 / 调试 | `diagnosing-bugs` |
| 代码审查 | `code-review` |

### Java 后端的强制加载规则（`workgroup.yaml` 的摘要）

出现下列任意一项，必须在执行该任务前先 `read` 对应 skill 全文，不得跳过：

1. prompt 出现 Maven 模块名 `<MOD>-api` / `<MOD>-component` / `<MOD>-service` / `<MOD>-web`
2. prompt 出现 `.java` / `.xml` / `.sql` 文件路径，且目标位于 `<BE_REPO>/<MOD>-*` 下
3. prompt 出现目录路径，且该目录下扫到 `.java` / `.xml` / `.sql` 文件
4. 准备用 edit / write / multi_edit / `mcp__idea__execute_tool` 的 create_new_file 改动 `<MOD>-*` 下的 `.java` / `.xml` / `.sql`

完整规则表见仓库根 `workgroup.yaml` 的 `spec.members[].skills.forceLoadRules`（本文档只是摘要）。读完后只保留与本次任务相关的章节作为参考，避免占满 context。

### 反模式

- ❌ 不读 A 类本地规范就直接写代码
- ❌ 读了却忽略其约束（"我大概知道"）
- ❌ 只在出错时才回去看 skill
- ❌ 把 skill 当成"参考资料"而不是"约束"
- ❌ 只调本文档点名的 B 类 skill，忽略 settings.json 里其他同样可用的

## 四、后端构建与编译（强制）

**核心原则**：后端的 build / compile / start / restart 是 IDE 的活，shell 脚本是绕路。历史上曾为此类绕路写大量临时脚本，浪费 token 且反复失败。

### 强约束

1. ✅ 后端的 build / compile / start / restart **必须**走 IDE 提供的 MCP 工具，不走 shell 命令行
2. ❌ **禁止**在任何临时目录新建 `*.py` / `*.sh` / `*.bat` / `*.ps1` 脚本代替 IDE MCP
3. ❌ **禁止**直接调 `javac` / `mvn` / `java` / `mvnw` 绕开 IDE——除非 IDE MCP 已明确失败并向用户报错
4. ❌ **禁止**主动跑 `mvn clean` / `mvn install` 等价的 shell 命令
5. ✅ 失败就报回让用户介入，不要自己造轮子
6. ✅ 用 IDE MCP 的 `get_file_problems` 验证改完后的编译错
7. ✅ IDE MCP 不可用时 → 立即停止 + 报错，不静默 fallback 到 shell

### dev server 重启流程（标准操作）

1. 改完 Java 文件
2. **不信任 build 工具返回的成功标志**——手动验证产物时间戳（jar / class）
3. 若产物未更新 → 直接手动 `rm -rf` 对应模块的 `target/` 目录（比 `mvn clean` 更可靠）
4. 调 IDE MCP 重新 build
5. 杀掉 dev server 进程 + 清监听端口
6. 调 IDE MCP 重启
7. 等启动完成（看日志里的 "Started Application" 类标志）
8. HTTP 探活直到 200

### dev server 启动失败的根因排查

历史教训：只改 Java 文件 + 跑 build，但**依赖模块的 fat jar 还是上次 build 的旧产物**（时间戳未变）。dev server 加载旧 jar → 找不到新 class → 启动失败，而 IDE 只报 "Process not started"，不报具体错。

**所以 build 后必须手动验证**：

- ❌ **不要**只看 build 工具的 isSuccess / exit code
- ✅ 必须 `ls -la` 看产物的 mtime，确认本次 build 真的生成了新产物
- ❌ 不要用 `mvn clean` 代替手动删 target
- ✅ 启动失败时不瞎重启，先 `find` 确认目标 class 实际生成
- ✅ 看 IDE 自己的 run log（不是 build log）找启动错——**那是 dev server 唯一报错输出**

### 反模式（禁止）

- ❌ 写 `compile_*.py` / `fix_*.py` / `revert_*.py` / `diag_*.py` / `orca_*.py` / `e2e_*.py` 之类脚本——build 是 IDE 的活
- ❌ 写脚本"我手动跑一遍"代替 IDE MCP
- ❌ 启动失败时不查 classpath 实际产物就盲目重启
- ❌ 把根因固化成脚本而不是写到本文件

### 正模式

- ✅ 改 Java → IDE MCP build → IDE MCP restart → HTTP 探活，三步搞定
- ✅ 端口探测：用 IDE MCP 的 terminal 命令跑系统端口查询工具
- ✅ 看日志：用 IDE MCP 的 terminal 命令读启动 log
- ✅ DB 查询：用 IDE MCP 的 SQL 工具（**只对当前 dev 环境连接可写，其他连接只读**）
- ✅ 真根因记到本文件，不写脚本固化

## 五、Git 提交（绝对禁止自主操作）

**强约束**：没有用户直接开口要你做 git 操作，就严令静止。

### 定义：什么算「用户直接要」

只有用户在**当前对话里、用祈使句、直接指向 git 动作**才算。例：「提交一下」「commit」「push 上去」「把这个 commit 掉」。

### 下列全部不算授权，一次都不算

| ❌ 不算 | 例子 / 说明 |
|---|---|
| 上文里的「Next Steps」清单 | 那是你**自己**列的待办，不是用户的要求。自己写的计划不能当授权 |
| 你自己写进某个文件的「维护流程」「后续步骤」 | **自我授权**。你在配置里写「改完记得 commit」，不构成用户许可，且会给后续 agent 开口子 |
| 之前的会话摘要 / 历史习惯 / 「上次都提交了」 | 历史不是许可。每次都要重新问 |
| 「修完不同步一下没意义」「worktree 副本会落后」 | **技术必要性不是授权**。理由再充分也不能替代用户开口 |
| 隐含在任务描述里的（"按规范整改仓库""保持副本同步"） | 规范文件里写的流程 ≠ 用户此刻的指令 |
| 你自己的收尾话术 | 「已修复、commit、push」——把提交当默认收尾步，正是本条禁止的形态 |

### 明令禁止的行为

1. ❌ **不得执行** `git add` / `git commit` / `git push` / `git checkout` / `git stash` / `git reset` 等任何会改变仓库状态或远端的 git 操作
2. ❌ **不得诱导**：不问「是否需要提交？」「要不要我帮你 commit？」「需要我推送吗？」「要我顺手 commit 一下吗？」
3. ❌ **不得暗示**：不在收尾段落把提交写成下一步、不列「接下来：commit / push」作为待办
4. ❌ **不得主动生成** commit message / changelog / 版本号 / 分支名建议
5. ❌ **不得把 git 操作写进任何 skill / 文档的「维护流程」当作常态**；写到文档里时只能写成「提交与推送交由用户决定」
6. ❌ **不得用 push 当作"修复完成"的证明**并写进回复

### 正确做法

1. ✅ 改完文件，只跑只读验证（lint / tsc / 自检脚本）
2. ✅ 报告：改了哪些文件 + 验证结果 + 跳过什么
3. ✅ **到此为止**。不提 git，不提提交，不提推送，不问要不要
4. ✅ 用户之后自己开口要提交时，才执行——且只执行他明确说的那一步

### 自我检查（动手前必问自己一句）

> 「用户这句话里，有没有一个字是他用来命令我做 git 的？」

没有 → 不动 git。哪怕任务看起来"就该提交"。

**任何对本规则的弱化、绕过、暗示都被视为违规。** 这条规则优先于任何 skill 里写到的流程，也优先于你自己认为的「完成任务」标准。

## 六、输出纪律（强制，防止 token 死循环）

**问题根因**：历史上曾出现 assistant 输出里同一填充词重复上千次（用户投诉控制台刷屏）。成因是思考流泄漏进正文 + 无长度自检。

### 强约束

1. ✅ **思考留在内部，只输出结论**——不写"等等"、不复述用户指令、不自我解释、不重复上一句已说过的话
2. ✅ **同一段落里同一非代码 token 最多出现 2 次**——出现第 3 次立刻停下
3. ✅ **单次回复 ≤ 20 行**，除非用户明确要长报告
4. ✅ **改完只报 3 件事**：改了哪些文件、验证结果（具体验证工具 + 行数）、跳过什么及原因
5. ❌ **禁止**在任何回复里出现"等等""稍等""让我看看""接下来"作为过渡填充
6. ❌ **禁止**把思考过程（wait / think / considering / 让我想）写进正文

### 自检（每条回复发出前过一遍）

- 有没有连续 3 个相同的非代码 token？有 → 删。
- 有没有在解释"我为什么这么做"？有 → 删，只留结论。
- 有没有超过 20 行？有 → 压成表格。

## 七、任务收尾"用户等什么"清单

### 必做

- ✅ 跑**只针对本次修改文件**的 lint（不准传目录 / `.` / glob，**禁止 `--fix`**）
- ✅ 跑**只针对本次修改文件**的类型检查（不准全量）
- ✅ 报告 lint + 类型检查的实际输出（行数 / 错数）

### 禁止

- ❌ 跑 `pnpm lint` / `npx eslint src` / `eslint .` 之类全量
- ❌ 用任何 lint / format 的 `--fix` 自动改代码
- ❌ 主动 git add / commit / push
- ❌ 主动跑 build（除非用户明确要求）

## 八、配置与记忆位置

### 配置

- **实际生效的包与 skill 清单**：`.pi/settings.json`
- **本地 Vue 3 / TypeScript 规则**：`.pi/skills/vue/`、`.pi/skills/typescript/`
- **本地 Java 8 规则**：`.pi/skills/java-rules/`、`.pi/skills/legacy-stack-overrides/`
- **共享 MCP 配置**：同时启用 `idea` 与 `context-mode`（本地 stdio，已内置）

### 记忆（本 agent 的持久记忆只在这三处，不在外部记忆服务）

| 位置 | 存什么 | 进上下文的方式 |
|---|---|---|
| 本 `AGENTS.md` | 规则记忆：范围、硬约束、skill 路由、踩坑结论 | session 启动时由 Pi 原生注入 |
| `.pi/context/*.md` | 通用行为准则（`<cwd>/.pi/context` 下直接子文件） | session 启动时由 `context-md-loader` 扩展注入 |
| `.pi/skills/` + `.pi/git/<host>/<repo>/` | 规范记忆：A 类本地 skill 与外部 clone 的 skill 正文 | 任务相关时按路由表 `read` SKILL.md |
| `PM/` | 交付记忆：需求文档、执行报告、SQL、流程图、工时 | 按需 `read`，不进上下文直到读了 |

> `.pi/write-allowlist.json`、`.pi/codegraph-projects.cache.json`、`.pi/skill-stats.json` 是**机器读的运行时产物**，不构成记忆，也不产生 prompt token。